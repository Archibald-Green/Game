from django.apps import AppConfig


class CskConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'csk'
